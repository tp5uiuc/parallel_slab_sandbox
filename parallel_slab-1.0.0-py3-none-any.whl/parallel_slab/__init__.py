#!/usr/bin/env python3

__doc__ = """Shear benchmark for an elastic solid--fluid layers sandwiched between two oscillatory moving walls"""

from .solutions import (
    ProblemSolution,
    NeoHookeanSolution,
    GeneralizedMooneyRivlinSolution,
)
from ._driver import run_NeoHookeanSolution_from
